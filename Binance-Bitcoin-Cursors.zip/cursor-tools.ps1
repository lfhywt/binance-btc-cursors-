﻿$ErrorActionPreference = 'Stop'

$script:CursorSchemeName = 'Binance x Bitcoin - Black Gold'
$script:CursorRegistryPath = 'Control Panel\Cursors'
$script:CursorSchemesPath = 'Control Panel\Cursors\Schemes'
$script:CursorInstallRoot = Join-Path $env:LOCALAPPDATA 'BinanceBitcoinCursors'
$script:CursorSizeValueName = 'CursorBaseSize'
$script:CursorDefaultBaseSize = 32
$script:SpiSetCursors = 0x0057
$script:SpiSetCursorSize = 0x2029
$script:SpifUpdateIniFile = 0x01
$script:SpifSendChange = 0x02
$script:CursorMapping = [ordered]@{
    Arrow       = '01-normal.cur'
    Help        = '02-help.cur'
    AppStarting = '03-working.cur'
    Wait        = '04-busy.cur'
    Crosshair   = '05-precision.cur'
    IBeam       = '06-text.cur'
    NWPen       = '07-handwriting.cur'
    No          = '08-unavailable.cur'
    SizeNS      = '09-resize-ns.cur'
    SizeWE      = '10-resize-we.cur'
    SizeNWSE    = '11-resize-nwse.cur'
    SizeNESW    = '12-resize-nesw.cur'
    SizeAll     = '13-move.cur'
    UpArrow     = '14-alternate.cur'
    Hand        = '15-link.cur'
    Pin         = '16-pin.cur'
    Person      = '17-person.cur'
}
$script:CursorRequiredFiles = @($script:CursorMapping.Values) + @('18-bitcoin-normal.cur')

function Initialize-CursorNative {
    if (-not ('BinanceBitcoin.CursorNative' -as [type])) {
        Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
namespace BinanceBitcoin {
    public static class CursorNative {
        [DllImport("user32.dll", SetLastError = true)]
        public static extern bool SystemParametersInfo(uint action, uint param, IntPtr value, uint flags);
        [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        public static extern IntPtr LoadImage(IntPtr instance, string name, uint type, int cx, int cy, uint flags);
        [DllImport("user32.dll", SetLastError = true)]
        public static extern bool DestroyCursor(IntPtr cursor);
    }
}
'@
    }
}

function Assert-CursorAssets([string]$Directory, [int]$ExpectedSize = 0) {
    Initialize-CursorNative
    foreach ($file in $script:CursorRequiredFiles) {
        $path = Join-Path $Directory $file
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
            throw "缺少指针文件：$path。请先完整解压压缩包，再运行安装。"
        }
    }
    $assets = @(Get-ChildItem -LiteralPath $Directory -Filter '*.cur' -File | Sort-Object Name)
    foreach ($asset in $assets) {
        $file = $asset.Name
        $path = $asset.FullName
        $bytes = [System.IO.File]::ReadAllBytes($path)
        if ($bytes.Length -lt 22 -or [BitConverter]::ToUInt16($bytes, 0) -ne 0 -or
            [BitConverter]::ToUInt16($bytes, 2) -ne 2 -or [BitConverter]::ToUInt16($bytes, 4) -lt 1) {
            throw "指针文件格式不正确：$file"
        }
        $frameCount = [BitConverter]::ToUInt16($bytes, 4)
        $tableEnd = 6 + 16 * $frameCount
        if ($bytes.Length -lt $tableEnd) { throw "指针文件目录不完整：$file" }
        if ($ExpectedSize -gt 0 -and $frameCount -ne 1) {
            throw "固定 $($ExpectedSize)px 目录中的 $file 必须只有 1 个图像帧，当前为 $frameCount 个。"
        }
        for ($frame = 0; $frame -lt $frameCount; $frame++) {
            $entry = 6 + 16 * $frame
            $width = [int]$bytes[$entry]
            $height = [int]$bytes[$entry + 1]
            if ($width -eq 0) { $width = 256 }
            if ($height -eq 0) { $height = 256 }
            if ($ExpectedSize -gt 0 -and ($width -ne $ExpectedSize -or $height -ne $ExpectedSize)) {
                throw "$file 的尺寸为 $($width)x$height，与所选 $($ExpectedSize)px 不符。"
            }
            $hotspotX = [BitConverter]::ToUInt16($bytes, $entry + 4)
            $hotspotY = [BitConverter]::ToUInt16($bytes, $entry + 6)
            $dataLength = [long][BitConverter]::ToUInt32($bytes, $entry + 8)
            $dataOffset = [long][BitConverter]::ToUInt32($bytes, $entry + 12)
            if ($hotspotX -ge $width -or $hotspotY -ge $height -or $dataLength -le 0 -or
                $dataOffset -lt $tableEnd -or ($dataOffset + $dataLength) -gt $bytes.LongLength) {
                throw "指针文件的热点或图像数据范围不正确：$file"
            }
        }
        $loadFlags = 0x10
        if ($ExpectedSize -eq 0) { $loadFlags = 0x50 }
        $handle = [BinanceBitcoin.CursorNative]::LoadImage([IntPtr]::Zero, $path, 2, $ExpectedSize, $ExpectedSize, $loadFlags)
        if ($handle -eq [IntPtr]::Zero) {
            throw "Windows 无法读取指针文件：$file（错误 $([Runtime.InteropServices.Marshal]::GetLastWin32Error())）"
        }
        [void][BinanceBitcoin.CursorNative]::DestroyCursor($handle)
    }
    return [pscustomobject]@{ Count = $assets.Count; Files = @($assets | ForEach-Object { $_.Name }) }
}

function Get-CursorRegistrySnapshot([string]$Path, [string[]]$Names) {
    $key = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey($Path, $false)
    try {
        $existing = @()
        if ($null -ne $key) { $existing = @($key.GetValueNames()) }
        $values = @(foreach ($name in $Names) {
            $exists = $existing -contains $name
            $kind = $null
            $value = $null
            if ($exists) {
                $kind = [int]$key.GetValueKind($name)
                $value = $key.GetValue($name, $null, [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
            }
            [pscustomobject]@{ Name = $name; Exists = $exists; Kind = $kind; Value = $value }
        })
        return [pscustomobject]@{ Path = $Path; KeyExisted = ($null -ne $key); Values = $values }
    }
    finally { if ($null -ne $key) { $key.Dispose() } }
}

function Set-CursorRegistrySnapshot($Snapshot) {
    $allowed = @($script:CursorRegistryPath, $script:CursorSchemesPath)
    if ($allowed -notcontains [string]$Snapshot.Path) { throw '备份中的注册表位置不符合预期。' }
    $key = [Microsoft.Win32.Registry]::CurrentUser.CreateSubKey([string]$Snapshot.Path)
    try {
        foreach ($entry in $Snapshot.Values) {
            if ($entry.Exists) {
                $kind = [Microsoft.Win32.RegistryValueKind][int]$entry.Kind
                $value = $entry.Value
                if ($kind -eq [Microsoft.Win32.RegistryValueKind]::DWord) { $value = [int]$value }
                elseif ($kind -eq [Microsoft.Win32.RegistryValueKind]::QWord) { $value = [long]$value }
                elseif ($kind -eq [Microsoft.Win32.RegistryValueKind]::MultiString) { $value = [string[]]$value }
                elseif ($kind -eq [Microsoft.Win32.RegistryValueKind]::Binary -or $kind -eq [Microsoft.Win32.RegistryValueKind]::None) { $value = [byte[]]$value }
                $key.SetValue([string]$entry.Name, $value, $kind)
            }
            else { $key.DeleteValue([string]$entry.Name, $false) }
        }
    }
    finally { $key.Dispose() }
}

function Get-CursorCurrentState([string[]]$SchemeNames = @($script:CursorSchemeName)) {
    $names = @('') + @($script:CursorMapping.Keys) + @('Scheme Source') + @($script:CursorSizeValueName)
    return [pscustomobject]@{
        Cursors = Get-CursorRegistrySnapshot $script:CursorRegistryPath $names
        Scheme = Get-CursorRegistrySnapshot $script:CursorSchemesPath $SchemeNames
    }
}

function Restore-CursorState($State) {
    Set-CursorRegistrySnapshot $State.Cursors
    Set-CursorRegistrySnapshot $State.Scheme
}

function Get-CursorBaseSize {
    $key = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey($script:CursorRegistryPath, $false)
    try {
        if ($null -ne $key) {
            $value = $key.GetValue($script:CursorSizeValueName, $null)
            $size = 0
            if ($null -ne $value -and [int]::TryParse([string]$value, [ref]$size) -and $size -gt 0) { return $size }
        }
    }
    finally { if ($null -ne $key) { $key.Dispose() } }
    return $script:CursorDefaultBaseSize
}

function Set-CursorBaseSize([int]$Size) {
    # Windows 会把不同内嵌尺寸的 CUR 统一缩放到 CursorBaseSize 再显示。
    # 不同步这个值，32/48/64/96 四套资源在屏幕上看起来完全一样。
    # SPI_SETCURSORS(0x0057) 只重载指针文件、不会重读尺寸；
    # 立即生效要用未文档化的 SPI_SETCURSORSIZE(0x2029)，pvParam 直接传像素值。
    Initialize-CursorNative
    $applied = [BinanceBitcoin.CursorNative]::SystemParametersInfo($script:SpiSetCursorSize, 0, [IntPtr]$Size, $script:SpifUpdateIniFile)
    if (-not $applied) {
        # 旧系统不支持该动作时至少写入注册表，注销后生效。
        $key = [Microsoft.Win32.Registry]::CurrentUser.CreateSubKey($script:CursorRegistryPath)
        try { $key.SetValue($script:CursorSizeValueName, $Size, [Microsoft.Win32.RegistryValueKind]::DWord) }
        finally { $key.Dispose() }
    }
    return [bool]$applied
}

function Set-CursorBaseSizeFromState($State) {
    # 旧版备份（Format 1）没有记录 CursorBaseSize，此时保持当前指针大小。
    $entry = @($State.Cursors.Values | Where-Object { [string]$_.Name -eq $script:CursorSizeValueName })
    if ($entry.Count -eq 0 -or -not $entry[0].Exists -or $null -eq $entry[0].Value) { return $false }
    return (Set-CursorBaseSize -Size ([int]$entry[0].Value))
}

function Get-CursorRestoreDepth([string]$InstallId) {
    $depth = 0
    $current = $InstallId
    $visited = @{}
    while ($current -and -not $visited.ContainsKey($current)) {
        $visited[$current] = $true
        $backupPath = Join-Path (Join-Path (Join-Path $script:CursorInstallRoot 'installs') $current) 'before-install.clixml'
        if (-not (Test-Path -LiteralPath $backupPath -PathType Leaf)) { break }
        $depth++
        try {
            $backup = Import-Clixml -LiteralPath $backupPath
            $current = [string]$backup.PreviousInstallId
        }
        catch { break }
    }
    return $depth
}

function Assert-CursorAppliedPaths([string]$Directory) {
    $key = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey($script:CursorRegistryPath, $false)
    if ($null -eq $key) { throw '无法读取刚写入的指针设置。' }
    try {
        $mismatches = @()
        foreach ($role in $script:CursorMapping.Keys) {
            $expected = Join-Path $Directory $script:CursorMapping[$role]
            $actual = [string]$key.GetValue($role, '', [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
            if (-not [string]::Equals($actual, $expected, [StringComparison]::OrdinalIgnoreCase)) {
                $mismatches += $role
            }
        }
        if ($mismatches.Count -gt 0) { throw ('指针设置读回不一致：' + ($mismatches -join ', ')) }
        return $script:CursorMapping.Count
    }
    finally { $key.Dispose() }
}

function Update-CursorDisplay {
    Initialize-CursorNative
    if (-not [BinanceBitcoin.CursorNative]::SystemParametersInfo($script:SpiSetCursors, 0, [IntPtr]::Zero, $script:SpifSendChange)) {
        throw "Windows 未能刷新指针（错误 $([Runtime.InteropServices.Marshal]::GetLastWin32Error())）。"
    }
}

function Get-CursorActiveInstallId {
    $pointer = Join-Path $script:CursorInstallRoot 'active-install.txt'
    if (-not (Test-Path -LiteralPath $pointer -PathType Leaf)) { return '' }
    $value = [System.IO.File]::ReadAllText($pointer).Trim()
    if ($value -and $value -notmatch '^\d{8}_\d{6}_\d{3}_[0-9a-f]{8}$') {
        throw '安装记录格式不正确。原设置没有被更改。'
    }
    return $value
}

function Set-CursorActiveInstallId([string]$InstallId) {
    $pointer = Join-Path $script:CursorInstallRoot 'active-install.txt'
    $temporary = Join-Path $script:CursorInstallRoot ('active-install.' + [Guid]::NewGuid().ToString('N') + '.tmp')
    [System.IO.File]::WriteAllText($temporary, $InstallId, [System.Text.UTF8Encoding]::new($false))
    Move-Item -LiteralPath $temporary -Destination $pointer -Force
}
