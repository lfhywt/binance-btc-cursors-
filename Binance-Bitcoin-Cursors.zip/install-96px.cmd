@echo off
setlocal
chcp 65001 >nul
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1" -Size 96
set "CURSOR_EXIT=%errorlevel%"
echo.
pause
exit /b %CURSOR_EXIT%
