﻿$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'cursor-tools.ps1')

$beforeRestore = $null
$restoreStarted = $false
try {
    $installId = Get-CursorActiveInstallId
    if (-not $installId) {
        Write-Host '没有待恢复的安装记录；当前指针未更改。'
        exit 0
    }
    $installDirectory = Join-Path (Join-Path $script:CursorInstallRoot 'installs') $installId
    $backupPath = Join-Path $installDirectory 'before-install.clixml'
    if (-not (Test-Path -LiteralPath $backupPath -PathType Leaf)) { throw "找不到原指针备份：$backupPath" }
    $backup = Import-Clixml -LiteralPath $backupPath
    $currentSid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    if (@(1, 2) -notcontains $backup.Format -or $backup.InstallId -ne $installId -or $backup.UserSid -ne $currentSid) {
        throw '备份与当前安装或当前 Windows 账户不匹配。'
    }
    $previousId = [string]$backup.PreviousInstallId
    if ($previousId -and $previousId -notmatch '^\d{8}_\d{6}_\d{3}_[0-9a-f]{8}$') { throw '备份中的历史安装编号不正确。' }
    $restoreSchemeNames = @($backup.State.Scheme.Values | ForEach-Object { [string]$_.Name })
    if ($restoreSchemeNames.Count -ne 1 -or
        $restoreSchemeNames[0] -notmatch '^Binance x Bitcoin - Black Gold( - (32|48|64|96|256)px)?$') {
        throw '备份中的指针方案名称不符合预期。'
    }
    if ($backup.Format -eq 2 -and [string]$backup.SchemeName -ne $restoreSchemeNames[0]) {
        throw '备份中的方案名称与快照不一致。'
    }
    $beforeRestore = Get-CursorCurrentState -SchemeNames $restoreSchemeNames
    $restoreStarted = $true
    Restore-CursorState $backup.State
    $sizeRestored = Set-CursorBaseSizeFromState $backup.State
    Update-CursorDisplay
    Set-CursorActiveInstallId $previousId
    Write-Host '已恢复到本次安装前的鼠标指针。' -ForegroundColor Green
    Write-Host '指针文件和备份仍保留在本地，不会删除。'
    if ($sizeRestored) {
        Write-Host "系统指针大小：已还原为 $(Get-CursorBaseSize)px。"
    }
    else {
        Write-Host "系统指针大小：旧备份未记录该设置，保持当前 $(Get-CursorBaseSize)px 不变。" -ForegroundColor Yellow
    }
    $remaining = Get-CursorRestoreDepth $previousId
    if ($remaining -gt 0) {
        Write-Host "还有 $remaining 层更早的安装备份；再次运行 restore.cmd 可继续向前恢复。" -ForegroundColor Yellow
    }
    exit 0
}
catch {
    $failure = $_.Exception.Message
    if ($restoreStarted -and $null -ne $beforeRestore) {
        try {
            Restore-CursorState $beforeRestore
            [void](Set-CursorBaseSizeFromState $beforeRestore)
            Update-CursorDisplay
            Set-CursorActiveInstallId $installId
            Write-Host '恢复未完成，已保留恢复前的指针设置。' -ForegroundColor Yellow
        }
        catch { Write-Host "回滚未完成：$($_.Exception.Message)。备份仍保留在 $installDirectory。" -ForegroundColor Red }
    }
    Write-Host "恢复失败：$failure" -ForegroundColor Red
    exit 1
}
