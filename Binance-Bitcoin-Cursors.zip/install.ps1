﻿param(
    [ValidateSet('Auto', '32', '48', '64', '96', '256')]
    [string]$Size = 'Auto',
    [switch]$ValidateOnly
)

$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'cursor-tools.ps1')

$beforeState = $null
$previousId = ''
$registryStarted = $false
try {
    $expectedSize = 0
    $selectedSizeText = 'Auto（自动选择）'
    if ($Size -eq 'Auto') {
        $sourceAssets = Join-Path $PSScriptRoot 'cursors'
    }
    else {
        $expectedSize = [int]$Size
        $selectedSizeText = "$($Size)px（单尺寸资源）"
        $sourceAssets = Join-Path (Join-Path $PSScriptRoot 'sizes') ($Size + 'px')
        $script:CursorSchemeName += " - $($Size)px"
    }
    $assetCheck = Assert-CursorAssets -Directory $sourceAssets -ExpectedSize $expectedSize
    if ($ValidateOnly) {
        Write-Host "验证通过：$selectedSizeText，共 $($assetCheck.Count) 个指针文件可被 Windows 读取。" -ForegroundColor Green
        Write-Host "包含 17 个标准系统状态及 $($assetCheck.Count - 17) 个备选或扩展素材；未修改系统设置。"
        if ($expectedSize -gt 0) { Write-Host "已确认每个 CUR 只有 1 个 $($Size)x$Size 图像帧。" }
        exit 0
    }

    $previousId = Get-CursorActiveInstallId
    $installId = (Get-Date -Format 'yyyyMMdd_HHmmss_fff') + '_' + [Guid]::NewGuid().ToString('N').Substring(0, 8)
    $installDirectory = Join-Path (Join-Path $script:CursorInstallRoot 'installs') $installId
    $installedAssets = Join-Path $installDirectory 'cursors'
    New-Item -ItemType Directory -Path $installedAssets -Force | Out-Null

    foreach ($file in $assetCheck.Files) {
        Copy-Item -LiteralPath (Join-Path $sourceAssets $file) -Destination (Join-Path $installedAssets $file)
    }
    $installedCheck = Assert-CursorAssets -Directory $installedAssets -ExpectedSize $expectedSize
    $beforeState = Get-CursorCurrentState
    $backup = [pscustomobject]@{
        Format = 2
        InstallId = $installId
        PreviousInstallId = $previousId
        SelectedSize = $Size
        SchemeName = $script:CursorSchemeName
        CreatedAt = (Get-Date).ToString('o')
        UserSid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
        State = $beforeState
    }
    $backup | Export-Clixml -LiteralPath (Join-Path $installDirectory 'before-install.clixml') -Encoding UTF8
    foreach ($helper in @('restore.cmd', 'restore.ps1', 'cursor-tools.ps1')) {
        Copy-Item -LiteralPath (Join-Path $PSScriptRoot $helper) -Destination (Join-Path $installDirectory $helper)
    }

    $registryStarted = $true
    $cursorKey = [Microsoft.Win32.Registry]::CurrentUser.CreateSubKey($script:CursorRegistryPath)
    try {
        $schemePaths = @()
        foreach ($role in $script:CursorMapping.Keys) {
            $assetPath = Join-Path $installedAssets $script:CursorMapping[$role]
            $cursorKey.SetValue($role, $assetPath, [Microsoft.Win32.RegistryValueKind]::String)
            $schemePaths += $assetPath
        }
        $cursorKey.SetValue('', $script:CursorSchemeName, [Microsoft.Win32.RegistryValueKind]::String)
        $cursorKey.SetValue('Scheme Source', 2, [Microsoft.Win32.RegistryValueKind]::DWord)
    }
    finally { $cursorKey.Dispose() }
    $schemeKey = [Microsoft.Win32.Registry]::CurrentUser.CreateSubKey($script:CursorSchemesPath)
    try { $schemeKey.SetValue($script:CursorSchemeName, ($schemePaths -join ','), [Microsoft.Win32.RegistryValueKind]::String) }
    finally { $schemeKey.Dispose() }

    # 固定尺寸资源必须同时把 Windows 指针大小设成对应像素，否则系统会把
    # 32/48/64/96 统一缩放到同一个尺寸，切换后屏幕上看不出区别。
    $sizeApplied = $true
    if ($expectedSize -gt 0) { $sizeApplied = Set-CursorBaseSize -Size $expectedSize }

    $appliedCount = Assert-CursorAppliedPaths -Directory $installedAssets
    Update-CursorDisplay
    Set-CursorActiveInstallId $installId
    Write-Host '已安装并应用：币安 × 比特币 · 黑金鼠标指针。' -ForegroundColor Green
    Write-Host "资源尺寸：$selectedSizeText"
    if ($expectedSize -gt 0) {
        if ($sizeApplied) {
            Write-Host "系统指针大小：已同步为 $($expectedSize)px，立即生效。" -ForegroundColor Green
        }
        else {
            Write-Host "系统指针大小：已写入 $($expectedSize)px，注销或重启 Windows 后生效。" -ForegroundColor Yellow
        }
    }
    else {
        Write-Host "系统指针大小：保持当前 $(Get-CursorBaseSize)px 不变，多尺寸资源会跟随系统设置。"
    }
    Write-Host "方案名称：$script:CursorSchemeName"
    Write-Host "系统指针设置已读回确认：$appliedCount/17。共复制 $($installedCheck.Count) 个 CUR 文件。"
    Write-Host 'Windows 可能继续根据显示缩放调整指针大小，资源尺寸不等于屏幕上的绝对像素尺寸。'
    Write-Host '比特币备选及扩展素材已复制，可在鼠标属性中手动选用。'
    Write-Host "原指针备份：$installDirectory"
    Write-Host '如需恢复，双击 restore.cmd。安装包解压目录可以移动，已安装的指针仍可使用。'
    exit 0
}
catch {
    $failure = $_.Exception.Message
    if ($registryStarted -and $null -ne $beforeState) {
        try {
            Restore-CursorState $beforeState
            [void](Set-CursorBaseSizeFromState $beforeState)
            Update-CursorDisplay
            Set-CursorActiveInstallId $previousId
            Write-Host '安装未完成，已恢复安装前的指针设置。' -ForegroundColor Yellow
        }
        catch { Write-Host "自动恢复未完成：$($_.Exception.Message)。备份位于 $installDirectory。" -ForegroundColor Red }
    }
    Write-Host "安装失败：$failure" -ForegroundColor Red
    exit 1
}
